import React, { useState, useCallback, useEffect, useContext, useRef  } from 'react'
import PropTypes from 'prop-types'
import { isFirefox } from "react-device-detect";
import { useScroll, useDrag  } from 'react-use-gesture'
import { useSpring, animated, interpolate, config } from 'react-spring'

import { ViewsContext } from '../context/ViewsContext'
import useSequencer from '../hooks/useSequencer'
// import useViews from '../hooks/useViews'

import Tracks from './tracks'
import BarDisplay from './barDisplay'

import vars from '../scss/_vars.scss';
import classes from './scrollControl.module.scss'


const ScrollControl = () => {

    const { zoom, trackView } = useContext(ViewsContext)[0]

    const { numBars, currentBar, updateCurrentBar, isPlaying, hasClipboard } = useSequencer()

    // const { zoom, trackView } = useViews()

    const axis = useRef()
    const scrollerRef = useRef()
    const scrollerContentRef = useRef()
    const draggerRef = useRef()
    const draggerContentRef = useRef()

    const [ isDragging, setIsDragging ] = useState(false)
    const [ isScrolling, setIsScrolling ] = useState(false)

    const [{ dragX, scrollX }, set] = useSpring(() => ({ dragX: 0, scrollX: 0, config: config.gentle }))

    const boundaries = useCallback(
        ref => {
          return ref.current.getBoundingClientRect()
        },
        []
    )

    const clampedResult = useCallback(
      (n, min, max) => {
        return Math.min(Math.max(n, min), max)
      },
      []
    )

    const segmentWidth = useCallback(
        (ref) => {
          const { width } = boundaries(ref)
          return width / numBars
        },
        [numBars]
    )

    const calculatePositionIndex = useCallback(
        (position, ref) => {
          const seg = segmentWidth(ref)
          const index = Math.round(position / seg)
          const clampedIndex = clampedResult(index, 0, numBars - 2)
          return clampedIndex
        },
        [numBars]
    )

    const moveDraggerTo = useCallback(
        (perc) => {
            const { width } =  boundaries(draggerRef)
            const boundaryWidth = boundaries(draggerContentRef).width
            setDraggerPosition(width * perc, 0, boundaryWidth, true, 0 )
        },
        []
    )

    const moveScrollerTo = useCallback(
        (perc) => {
            const { width } =  boundaries(scrollerContentRef)
            // scrollerRef.current.scrollLeft = Math.min(width * perc, width)
            set({
              scrollX: Math.min(width * perc, width)
              // immediate: down,
              // config: { velocity: velocity, decay: down }
            })
        },
        []
    )

    const setDraggerPosition = useCallback(
      (position, min, max, down, velocity) => {
        const draggerWidth = boundaries(draggerRef).width
        const clampedX = clampedResult(position, min, max - draggerWidth)
        set({
          dragX: clampedX,
          immediate: down,
          config: { velocity: velocity, decay: down }
        })
      }, []
    )

    const moveDragAndScroll = useCallback(
      (pos, controller, down, v) => {
        let newBarIndex
        const draggerBoundaryWidth = boundaries(draggerContentRef).width
        const scrollerBoundaryWidth = boundaries(scrollerContentRef).width
        const draggerWidth = boundaries(draggerRef).width
        const scrollerWidth = boundaries(scrollerRef).width
        const draggerSegment = segmentWidth(draggerContentRef)
        const scrollerSegment = segmentWidth(scrollerContentRef)
        if (controller === 'drag') { 
          console.log('dragging isDragging', isDragging)
          const clampedDragX = clampedResult(pos, 0, draggerBoundaryWidth - draggerWidth)
          newBarIndex = calculatePositionIndex(clampedDragX, draggerContentRef)
          console.log('dragging newBarIndex', newBarIndex)
          const restingDragX = clampedResult(draggerSegment * newBarIndex, 0, draggerBoundaryWidth - draggerWidth)
          const dragPosition = down ? clampedDragX : restingDragX
          const dragPercentage = dragPosition / draggerBoundaryWidth
          set({
            dragX: dragPosition,
            scrollX: Math.min(scrollerBoundaryWidth * dragPercentage, scrollerBoundaryWidth),
            immediate: down,
            config: { velocity: v, decay: down }
          })
          // setIsDragging(down)  
        } else { 
          if (!isDragging){
            console.log('scrolling pos', pos)
            const clampedScrollX = clampedResult(pos, 0, scrollerBoundaryWidth - scrollerWidth)
            newBarIndex = calculatePositionIndex(clampedScrollX, scrollerContentRef)
            const restingScrollX = clampedResult(scrollerSegment * newBarIndex, 0, scrollerBoundaryWidth - scrollerWidth)
            const scrollPosition = down ? clampedScrollX : restingScrollX
            const scrollPercentage = scrollPosition / scrollerWidth
            set({
              dragX: Math.min(draggerWidth * scrollPercentage, draggerBoundaryWidth - draggerWidth),
              scrollX: clampedScrollX,
              immediate: down,
              config: { velocity: v, decay: down }
            })
          }
        }
        updateCurrentBar(newBarIndex)
      },
      [],
    )

    const scrollerBind = useScroll(
        ({event, first, last, movement, velocity, direction: [dx, dy], memo = [scrollX.getValue()] }) => { // initial:[ix, iy], memo = [x.getValue(), y.getValue()]
          if (!isPlaying) {
            if (first) {
              // console.log('onScroll started isFirefox ', isFirefox ) 
              // console.log('onScroll started event', event ) 
              setIsScrolling(true)
            } 
            const pos = memo[0] + movement[0]
            const v = dx * velocity
            // console.log('scrollerBind memo[0] movement[0], v', memo[0], movement[0], v)
            moveDragAndScroll(pos, 'scroll', false, v)    
            !last && event.preventDefault()
            if (!axis.current) {
              if (Math.abs(dx) > Math.abs(dy)) axis.current = 'x'
              else if (Math.abs(dy) > Math.abs(dx)) axis.current = 'y'
            }
            // console.log('onScroll moving event ', event ) 
            // if (axis.current === 'x') set({ dragX: memo[0] + mx, immediate: true })
            // else if (axis.current === 'y') set({ draggerY: memo[1] + my, immediate: true })
            // if (!isFirefox) {
            //   if (axis.current === 'x' && trackView !== 1) {
            //     scrollerRef.current.style.overflowY= 'hidden'
            //   } else {
            //     scrollerRef.current.style.overflowX= 'hidden'
            //   } 
            // }   
            if (last) {
              // if (!isFirefox) {
              //   axis.current = null
              //   scrollerRef.current.style.overflowX = 'auto'
              //   scrollerRef.current.style.overflowY = 'auto'
              // }
              // console.log('onScroll ended event scrollerRef.current.scrollLeft', scrollerRef.current.scrollLeft)
              // const newBarIndex = calculatePositionIndex(scrollerRef.current.scrollLeft, scrollerContentRef)
              // if(!isDragging) {
              //   console.log('SCROLLER updateCurrentBar isDragging', isDragging)
              //   updateCurrentBar(newBarIndex)
              // }
              // const perc = scrollerRef.current.scrollLeft / boundaries(scrollerRef).width   
              setIsScrolling(false)  
              // setTimeout(() => {
              //   setIsScrolling(false)
              // }, 200) 
            } 
            else if(!isDragging){
              // const { width } = boundaries(scrollerRef)
              // const perc = scrollerRef.current.scrollLeft / width
              // moveDraggerTo(perc)
            }
            return memo
          } 
        }, 
        { 
          domTarget: scrollerRef,
          event: { passive: false }
        }
      )

      

      const draggerBind = useDrag(({ first, last, movement, down, velocity, direction, memo = [dragX.getValue()] }) => {
        if (!isPlaying) {
          const boundaryWidth = boundaries(draggerContentRef).width
          const seg = segmentWidth(draggerContentRef)
          const pos = memo[0] + movement[0]
          const v = direction[0] * velocity
          if (first) { 
              console.log('drag start')
              setIsDragging(true) 
          }
          if (last) { 
              // const newBarIndex = calculatePositionIndex(pos, draggerContentRef)
              // setDraggerPosition(seg * newBarIndex, 0, boundaryWidth, down, v )
              // if(!isScrolling){ 
              //   console.log('DRAGGER updateCurrentBar isScrolling', isScrolling) 
              //   updateCurrentBar(newBarIndex) 
              //   const perc = (seg * newBarIndex) / boundaryWidth
              //   // console.log('drag end perc', perc)
              //   moveScrollerTo(perc)
              // }
              // setIsDragging(false) 
              moveDragAndScroll(pos, 'drag', down, v)
              setTimeout(() => {
                setIsDragging(false) 
              }, 500)  
                  
          } else {
              // setDraggerPosition(pos, 0, boundaryWidth, down, v )
              moveDragAndScroll(pos, 'drag', down, v)
          }
          return memo
        }
    }, 
    {
        domTarget: draggerRef 
        // dragDelay: true,
        // drag: true, 
    })


    useEffect(() => {
        // scrollerRef.current.style.overflowX = (isPlaying) ? 'hidden' : 'auto'  
        if (!isDragging && !isScrolling) {
          // const boundaryWidth = boundaries(draggerContentRef).width
          // const seg = segmentWidth(draggerContentRef) 
          // const perc = (seg * currentBar) / boundaryWidth 
          // if (isPlaying) setDraggerPosition(seg * currentBar, 0, boundaryWidth, false, .25 )
          // moveScrollerTo(perc) 
        }     
    }, [currentBar, isPlaying])

    // useEffect(() => {      
    //   scrollerRef.current.style.overflowX = (isPlaying) ? 'hidden' : 'auto'
    // }, [isPlaying])

    // useEffect(() => {
    //   console.log('ScrollControl isPlaying', isPlaying)
    //   if (isPlaying) {
    //     scrollerRef.current.style.overflowX= 'hidden'
    //   } else {
    //     draggerBind()
    //     scrollerBind()
    //   }
    // },[draggerBind, scrollerBind, isPlaying])

    useEffect(draggerBind, [draggerBind])

    useEffect(scrollerBind, [scrollerBind])

    const marqueeStyle = {
        // transform: isDragging ? x.interpolate(x => `translateX(${x}px)`) : `translateX(${Math.min(currentBar * 100 / zoom, (numBars - zoom) * 100 / zoom)}%)`,
        transform: dragX.interpolate(dragX => `translateX(${dragX}px)`),
        transitionDuration: isDragging ? '0s' : '.15s',
        width: `${100 / numBars * zoom}%`, 
        borderStyle: hasClipboard ? 'dotted' : 'solid',
        borderColor: numBars === zoom ? 'transparent' : vars.greencolor,
        cursor: isPlaying ? 'default' : 'grab'
    }

    const scrollerStyle = {
      transform: scrollX.interpolate(scrollX => `translateX(-${scrollX}px)`),
    }

    return (
        <>
            <div className={classes.dragPane}>
                <animated.div ref={draggerRef} className={classes.marquee} style={marqueeStyle}></animated.div>
                <BarDisplay ref={draggerContentRef} />
            </div>
            <animated.div ref={scrollerRef} className={classes.scrollPane} scrollLeft={scrollX}>
                <Tracks ref={scrollerContentRef} />
            </animated.div>
        </>
    )
}

export default ScrollControl

/* {...scrollerBind()}  */

/* scrollLeft={scrollX} */